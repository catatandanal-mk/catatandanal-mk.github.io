/* Catatan Danal (versi HP) — pengaturan: site.json. Artikel: daftar-artikel.txt + berkas artikel-*.txt */
(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const fmtDate = (d) => {
    try { return new Date(d + 'T00:00:00').toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }); }
    catch { return d; }
  };
  const page = document.body.dataset.page;
  const main = $('#main');
  let site, posts = [];

  const ICON = {
    sun: '<svg class="i-sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>',
    moon: '<svg class="i-moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>',
    menu: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 6h16M4 12h16M4 18h16"/></svg>',
    search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>',
  };

  async function getJSON(u) {
    const r = await fetch(u, { cache: 'no-cache' });
    if (!r.ok) throw new Error(u + ' → ' + r.status);
    return r.json();
  }
  const socialLinks = () => {
    const s = site.social || {}, out = [];
    const add = (label, v, make) => { v = (v || '').trim(); if (v) out.push({ label, href: /^https?:|^mailto:/.test(v) ? v : make(v) }); };
    add('WhatsApp', s.whatsapp, (v) => 'https://wa.me/' + v.replace(/\D/g, ''));
    add('Instagram', s.instagram, (v) => 'https://instagram.com/' + v.replace(/^@/, ''));
    add('YouTube', s.youtube, (v) => 'https://youtube.com/@' + v.replace(/^@/, ''));
    add('Facebook', s.facebook, (v) => 'https://facebook.com/' + v);
    add('TikTok', s.tiktok, (v) => 'https://tiktok.com/@' + v.replace(/^@/, ''));
    add('GitHub', s.github, (v) => 'https://github.com/' + v);
    add('Email', s.email, (v) => 'mailto:' + v);
    return out;
  };
  const initial = () => esc((site.author.short || site.author.name || 'D').trim().charAt(0).toUpperCase());
  const avatar = (cls) =>
    `<div class="${cls}">${site.author.photo ? `<img src="${esc(site.author.photo)}" alt="Foto ${esc(site.author.short)}">` : initial()}</div>`;
  const frame = () => `<div class="frame">${site.author.photo
    ? `<img src="${esc(site.author.photo)}" alt="Foto ${esc(site.author.short)}">`
    : `<span class="initial">${initial()}</span>`}</div>`;
  async function getText(u) {
    const r = await fetch(u, { cache: 'no-cache' });
    if (!r.ok) throw new Error(u + ' → ' + r.status);
    return r.text();
  }
  function parsePost(slug, raw) {
    raw = raw.replace(/^﻿/, '').replace(/\r\n/g, '\n');
    const m = raw.match(/^---\n([\s\S]*?)\n---\n?/);
    const meta = {};
    let body = raw;
    if (m) {
      body = raw.slice(m[0].length);
      for (const line of m[1].split('\n')) {
        const i = line.indexOf(':');
        if (i < 1) continue;
        meta[line.slice(0, i).trim().toLowerCase()] = line.slice(i + 1).trim().replace(/^["']|["']$/g, '');
      }
    }
    if (/^(true|ya|yes)$/i.test(meta.draft || '')) return null;
    const text = body.replace(/```[\s\S]*?```/g, ' ').replace(/!\[[^\]]*\]\([^)]*\)/g, ' ')
      .replace(/\[([^\]]+)\]\([^)]*\)/g, '$1').replace(/[#>*_`~|-]+/g, ' ').replace(/\s+/g, ' ').trim();
    const words = text ? text.split(' ').length : 0;
    const d = meta.tanggal || meta.date || '';
    return {
      slug, body,
      title: meta.judul || meta.title || slug.replace(/^artikel-/, '').replace(/-/g, ' '),
      date: /^\d{4}-\d{2}-\d{2}$/.test(d) ? d : new Date().toISOString().slice(0, 10),
      category: meta.kategori || meta.category || 'Umum',
      tags: (meta.tag || meta.tags || '').split(',').map((t) => t.trim()).filter(Boolean),
      excerpt: meta.ringkasan || meta.excerpt || (text.length > 170 ? text.slice(0, 167).replace(/\s+\S*$/, '') + '…' : text),
      cover: meta.gambar || meta.cover || '',
      readingTime: Math.max(1, Math.round(words / 200)),
    };
  }
  async function loadPosts() {
    const names = (await getText('daftar-artikel.txt')).replace(/\r/g, '').split('\n')
      .map((l) => l.trim()).filter((l) => l && !l.startsWith('#'))
      .map((l) => l.replace(/\.txt$/, '')).filter((l) => /^[\w-]+$/.test(l));
    const got = await Promise.all(names.map(async (slug) => {
      try { return parsePost(slug, await getText(slug + '.txt')); }
      catch (e) { console.warn('Artikel dilewati (berkas tidak ditemukan):', slug); return null; }
    }));
    return got.filter(Boolean).sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : a.slug.localeCompare(b.slug)));
  }
  const postUrl = (slug) => 'post.html?p=' + encodeURIComponent(slug);

  function postCard(p) {
    return `<article class="card">${p.cover ? `<img class="cover" loading="lazy" src="${esc(p.cover)}" alt="">` : ''}
      <a class="card-link" href="${postUrl(p.slug)}">
        <span class="kicker">${esc(p.category)}</span>
        <h3>${esc(p.title)}</h3>
        <p>${esc(p.excerpt)}</p>
        <div class="meta">${fmtDate(p.date)} · ${p.readingTime} menit baca</div>
      </a></article>`;
  }
  function workCard(w) {
    const inner = `<span class="kicker">${esc(w.category)}</span>
      <h3>${esc(w.title)}</h3>
      ${w.status ? `<span class="badge">${esc(w.status)}</span>` : ''}
      <p>${esc(w.description)}</p>
      ${w.link ? '<span class="go">Lihat →</span>' : ''}`;
    return `<article class="card">${w.link
      ? `<a class="card-link" href="${esc(w.link)}" target="_blank" rel="noopener">${inner}</a>`
      : `<div class="card-link">${inner}</div>`}</article>`;
  }
  const countBy = (arr, key) => {
    const m = new Map();
    arr.forEach((x) => m.set(x[key], (m.get(x[key]) || 0) + 1));
    return [...m.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
  };

  /* ---------- Rangka halaman ---------- */
  function buildChrome() {
    document.documentElement.lang = 'id';
    const nav = site.nav.map((n) => `<a href="${esc(n.href)}"${n.page === page || (page === 'post' && n.page === 'blog') ? ' aria-current="page"' : ''}>${esc(n.label)}</a>`).join('');
    $('#chrome-top').innerHTML = `<div class="stripe"></div>
      <header class="site-header"><div class="wrap bar">
        <a class="brand" href="./"><span class="mark">${initial()}</span><span>${esc(site.title)}</span></a>
        <nav class="nav" id="nav" aria-label="Menu utama">${nav}</nav>
        <button class="icon-btn" id="themeBtn" aria-label="Ganti tema terang/gelap">${ICON.sun}${ICON.moon}</button>
        <button class="icon-btn" id="menuBtn" aria-label="Buka menu" aria-expanded="false">${ICON.menu}</button>
      </div></header>`;
    const soc = socialLinks();
    $('#chrome-bottom').innerHTML = `<footer class="site-footer"><div class="stripe"></div><div class="wrap foot">
      <p>© ${new Date().getFullYear()} ${esc(site.author.name)} · ${esc(site.title)}</p>
      <ul>${soc.map((s) => `<li><a href="${esc(s.href)}" target="_blank" rel="noopener">${s.label}</a></li>`).join('')}</ul>
    </div></footer>`;
    $('#themeBtn').addEventListener('click', () => {
      const t = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
      document.documentElement.setAttribute('data-theme', t);
      try { localStorage.setItem('theme', t); } catch (e) { /* abaikan */ }
    });
    $('#menuBtn').addEventListener('click', (e) => {
      const open = $('#nav').classList.toggle('open');
      e.currentTarget.setAttribute('aria-expanded', open);
    });
  }
  function setMeta(title, desc) {
    document.title = title;
    const set = (sel, attr, v) => { const el = $(sel); if (el) el.setAttribute(attr, v); };
    if (desc) { set('meta[name="description"]', 'content', desc); set('meta[property="og:description"]', 'content', desc); }
    set('meta[property="og:title"]', 'content', title);
  }
  function fail(e) {
    console.error(e);
    main.innerHTML = `<div class="error-box"><h2>Situs belum bisa memuat data</h2>
      <p>Jika Anda membuka <code>index.html</code> langsung dari penyimpanan HP/komputer, browser memblokir pemuatan data. Situs baru berfungsi setelah diunggah (GitHub Pages / Netlify); lihat PANDUAN.txt.</p></div>`;
  }

  /* ---------- Halaman ---------- */
  function home() {
    setMeta(site.title + ' — Blog & Portofolio', site.description);
    const latest = posts.slice(0, 6);
    const cats = countBy(posts, 'category');
    main.innerHTML = `
      <section class="hero">
        <div>
          <span class="eyebrow">${esc(site.author.name)}</span>
          <h1>${esc(site.tagline).replace(/^(\S+ \S+ \S+)/, '<em>$1</em>')}</h1>
          <p class="lead">${esc(site.description)}</p>
          <div class="actions"><a class="btn" href="blog.html">Baca artikel</a><a class="btn ghost" href="portfolio.html">Lihat portofolio</a></div>
        </div>
        ${frame()}
      </section>
      <div class="divider" aria-hidden="true"></div>
      <section class="section">
        <div class="section-head"><h2>Tulisan terbaru</h2><a href="blog.html">Semua artikel →</a></div>
        ${latest.length ? `<div class="grid">${latest.map(postCard).join('')}</div>` : '<div class="empty">Belum ada artikel. Tambahkan nama berkas artikel di <code>daftar-artikel.txt</code>.</div>'}
        ${cats.length ? `<ul class="chips" style="margin-top:26px">${cats.map(([c, n]) => `<li><a class="chip" href="blog.html?cat=${encodeURIComponent(c)}">${esc(c)}<small>${n}</small></a></li>`).join('')}</ul>` : ''}
      </section>
      <section class="section">
        <div class="section-head"><h2>Portofolio pilihan</h2><a href="portfolio.html">Semua karya →</a></div>
        <div class="grid">${site.portfolio.slice(0, 3).map(workCard).join('')}</div>
      </section>
      <section class="section">
        <div class="about-strip">${avatar('avatar')}
          <div><h2 style="margin-bottom:8px">Tentang penulis</h2><p>${esc(site.author.bio[0] || '')}</p><a class="btn ghost" href="about.html">Selengkapnya</a></div>
        </div>
      </section>`;
  }

  function blog() {
    setMeta('Artikel — ' + site.title, 'Kumpulan artikel ' + site.author.short + ' tentang pendidikan, karakter, dan nilai-nilai Minangkabau.');
    const params = new URLSearchParams(location.search);
    let cat = params.get('cat') || '', q = params.get('q') || '';
    const cats = countBy(posts, 'category');
    main.innerHTML = `
      <div class="page-head"><h1>Artikel</h1><p>${posts.length} tulisan. Cari berdasarkan kata kunci atau pilih topik.</p></div>
      <div class="toolbar">
        <label class="search"><span class="sr-only">Cari artikel</span>${ICON.search}<input id="q" type="search" placeholder="Cari judul, topik, atau tag…" value="${esc(q)}"></label>
        <div class="chips" id="cats"></div>
      </div>
      <div id="list" class="grid" aria-live="polite"></div>`;
    const draw = () => {
      $('#cats').innerHTML = [['', posts.length], ...cats].map(([c, n]) =>
        `<button class="chip" data-c="${esc(c)}" aria-pressed="${c === cat}">${c ? esc(c) : 'Semua'}<small>${n}</small></button>`).join('');
      const needle = q.trim().toLowerCase();
      const rows = posts.filter((p) => (!cat || p.category === cat) &&
        (!needle || (p.title + ' ' + p.excerpt + ' ' + p.category + ' ' + p.tags.join(' ')).toLowerCase().includes(needle)));
      $('#list').innerHTML = rows.length ? rows.map(postCard).join('') : '<div class="empty" style="grid-column:1/-1">Tidak ada artikel yang cocok.</div>';
      const u = new URL(location.href);
      cat ? u.searchParams.set('cat', cat) : u.searchParams.delete('cat');
      needle ? u.searchParams.set('q', q) : u.searchParams.delete('q');
      history.replaceState(null, '', u);
    };
    $('#q').addEventListener('input', (e) => { q = e.target.value; draw(); });
    $('#cats').addEventListener('click', (e) => { const b = e.target.closest('[data-c]'); if (b) { cat = b.dataset.c; draw(); } });
    draw();
  }

  async function post() {
    const slug = new URLSearchParams(location.search).get('p') || '';
    const meta = posts.find((p) => p.slug === slug);
    if (!/^[\w-]+$/.test(slug) || !meta) return notFound();
    const md = meta.body;
    setMeta(meta.title + ' — ' + site.title, meta.excerpt);
    const og = (p, v) => { const m = document.createElement('meta'); m.setAttribute('property', p); m.content = v; document.head.appendChild(m); };
    og('og:url', location.href);
    if (meta.cover) og('og:image', new URL(meta.cover, location.href).href);
    const html = DOMPurify.sanitize(marked.parse(md, { mangle: false, headerIds: false }), { ADD_ATTR: ['target'] });
    const i = posts.findIndex((p) => p.slug === slug);
    const newer = posts[i - 1], older = posts[i + 1];
    main.className = '';
    main.innerHTML = `<article class="post">
      <a class="back" href="blog.html">← Semua artikel</a>
      <span class="kicker">${esc(meta.category)}</span>
      <h1>${esc(meta.title)}</h1>
      <p class="meta">${esc(site.author.short)} · ${fmtDate(meta.date)} · ${meta.readingTime} menit baca</p>
      ${meta.cover ? `<img class="hero-img" src="${esc(meta.cover)}" alt="">` : ''}
      <div class="prose" id="prose">${html}</div>
      <div class="post-foot">
        ${meta.tags.length ? `<ul class="chips">${meta.tags.map((t) => `<li><a class="chip" href="blog.html?q=${encodeURIComponent(t)}">#${esc(t)}</a></li>`).join('')}</ul>` : ''}
        <div class="share"><span>Bagikan:</span>
          <a class="chip" target="_blank" rel="noopener" href="https://wa.me/?text=${encodeURIComponent(meta.title + ' — ' + location.href)}">WhatsApp</a>
          <a class="chip" target="_blank" rel="noopener" href="https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(location.href)}">Facebook</a>
          <button class="chip" id="copy" type="button">Salin tautan</button></div>
        <div class="author-box">${avatar('avatar')}<p><strong>${esc(site.author.name)}</strong><br>${esc(site.author.role)}</p></div>
        <nav class="pager" aria-label="Artikel lain">
          ${older ? `<a href="${postUrl(older.slug)}"><small>← Sebelumnya</small>${esc(older.title)}</a>` : '<span></span>'}
          ${newer ? `<a href="${postUrl(newer.slug)}"><small>Berikutnya →</small>${esc(newer.title)}</a>` : '<span></span>'}
        </nav>
      </div></article>`;
    $('#prose').querySelectorAll('a[href^="http"]').forEach((a) => { a.target = '_blank'; a.rel = 'noopener'; });
    $('#prose').querySelectorAll('img').forEach((im) => { im.loading = 'lazy'; });
    $('#copy').addEventListener('click', async () => {
      try { await navigator.clipboard.writeText(location.href); toast('Tautan disalin'); } catch (e) { toast('Salin manual dari address bar'); }
    });
    const bar = document.createElement('div'); bar.className = 'progress'; document.body.appendChild(bar);
    addEventListener('scroll', () => {
      const h = document.documentElement; const t = h.scrollHeight - h.clientHeight;
      bar.style.width = (t > 0 ? (h.scrollTop / t) * 100 : 0) + '%';
    }, { passive: true });
  }

  function portfolio() {
    setMeta('Portofolio — ' + site.title, 'Program, buku, dokumen, dan pelatihan yang dikerjakan ' + site.author.short + '.');
    const items = site.portfolio; let cat = '';
    const cats = countBy(items, 'category');
    main.innerHTML = `<div class="page-head"><h1>Portofolio</h1><p>Program, buku, dokumen kelembagaan, dan pelatihan yang saya rancang dan kerjakan.</p></div>
      <div class="toolbar"><div class="chips" id="cats"></div></div><div id="list" class="grid"></div>`;
    const draw = () => {
      $('#cats').innerHTML = [['', items.length], ...cats].map(([c, n]) =>
        `<button class="chip" data-c="${esc(c)}" aria-pressed="${c === cat}">${c ? esc(c) : 'Semua'}<small>${n}</small></button>`).join('');
      $('#list').innerHTML = items.filter((w) => !cat || w.category === cat).map(workCard).join('');
    };
    $('#cats').addEventListener('click', (e) => { const b = e.target.closest('[data-c]'); if (b) { cat = b.dataset.c; draw(); } });
    draw();
  }

  function about() {
    const a = site.author, soc = socialLinks();
    setMeta('Tentang — ' + site.title, a.bio[0]);
    main.innerHTML = `<section class="about">
      <div>${frame()}</div>
      <div>
        <h1>${esc(a.name)}</h1>
        <p class="role">${esc(a.role)} · ${esc(a.location)}</p>
        ${a.bio.map((p) => `<p>${esc(p)}</p>`).join('')}
        <h2 style="margin-top:34px;font-size:1.5rem">Yang saya tekuni</h2>
        <ul class="focus">${a.focus.map((f) => `<li><strong>${esc(f.title)}</strong><span>${esc(f.text)}</span></li>`).join('')}</ul>
        <div class="actions" style="display:flex;gap:12px;flex-wrap:wrap">
          ${soc.length ? soc.map((s) => `<a class="btn ghost" target="_blank" rel="noopener" href="${esc(s.href)}">${s.label}</a>`).join('') : '<a class="btn ghost" href="blog.html">Baca tulisan saya</a>'}
        </div>
      </div></section>`;
  }

  function notFound() {
    setMeta('Halaman tidak ditemukan — ' + (site ? site.title : ''));
    main.innerHTML = `<div class="error-box"><h2>Halaman tidak ditemukan</h2><p>Tautan yang Anda buka tidak ada atau artikelnya sudah dipindahkan.</p><p><a class="btn" href="./">Kembali ke beranda</a></p></div>`;
  }
  function toast(msg) {
    const t = document.createElement('div'); t.className = 'toast'; t.textContent = msg; document.body.appendChild(t);
    setTimeout(() => t.remove(), 1800);
  }

  (async () => {
    try {
      site = await getJSON('site.json');
      posts = await loadPosts();
    } catch (e) { return fail(e); }
    buildChrome();
    main.innerHTML = '';
    const routes = { home, blog, post, portfolio, about, notfound: notFound };
    try { await (routes[page] || notFound)(); } catch (e) { console.error(e); notFound(); }
  })();
})();
